# FelipeVerse

Este é um projeto básico para transformar imagens em vídeos com IA.

## Rodando localmente

1. Instale as dependências:
   ```
   npm install
   ```
2. Execute o servidor:
   ```
   npm start
   ```
3. Acesse `http://localhost:3000` para testar.